# TP1: SNAKE
### Algoritmos y programación I 
- Alumno: Barberis, Juan Celestino
- Pradrón: 105147
- Curso Essaya (Práctica Barbara)
- Ayudante: Javier Di Santo
- Segundo cuatrimestre 2019

## Comentario

El trabajo práctico me pareció muy entretenido. Fue un reto muy acorde para aplicar todo lo aprendido en las clases.

En cuanto a los problemas que se me presentaron a la hora de programar el juego, el que más me hizo pensar fue el de el movimiento de la serpiente, ya que nunca se me había ocurrido el hecho de tratar a la serpiente como una lista de listas con las coordenadas de la posición dentro del tablero. 

Gracias a las aclaraciones de los chicos de la práctica, me quedó todo más claro a partir de ahí y pude finalizar con mi código.

Otra situación en la que perdí mucho tiempo, fue en nombrar las variables y funciones, además de no poder hacerlo en inglés (como es común), tenía que ser lo más explícito posible en los nombres.

## Conclusión

Programar el juego SNAKE fue muy divertido, aprendí mucho Python y me motiva a seguir al día con los temas de la cursada. 