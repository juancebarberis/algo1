# NOMBRE_Y_APELLIDO = JUAN CELESTINO BARBERIS
# PADRÓN = 105147
# MATERIA = 7540 Algoritmos y Programación 1, curso Essaya
# Ejercicio 1 de entrega obligatoria


#Importo las funciones que necesito desde mi archivo vectores.py

from vectores import productoVectorial, norma, diferencia

#Defino la función areaTriangulo

def areaTriangulo(Ax, Ay, Az, Bx, By, Bz, Cx, Cy, Cz):
    """Esta función recibe tres vectores A, B y C en R3, y devuelve el área del triángulo que forman dichos vectores."""

    #Calculo la diferencia de los vectores AB y AC utilizando la función diferencia()
    ABx, ABy, ABz = diferencia(Ax, Ay, Az, Bx, By, Bz)
    ACx, ACy, ACz = diferencia(Ax, Ay, Az, Cx, Cy, Cz)
    
    #Llamo a la función productoVectorial() que importé y le paso las variables que calculé por medio de mi función diferencia()
    prodVectX, prodVectY, prodVectZ = (productoVectorial(ABx, ABy, ABz, ACx, ACy, ACz))
    
    #Ahora, calculo la norma con la función norma() pasandole los parametros que me devuelve productoVectorial() 
    resultadoNorma = norma(prodVectX, prodVectY, prodVectZ)
    
    #Divido ese resultado entre 2 para obtener el area del triángulo
    areaTriangulo = resultadoNorma / 2
    
    #Imprimo el resultado. 
    return print('Resultado del área del triángulo: ', areaTriangulo)


